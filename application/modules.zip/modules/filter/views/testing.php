<!-- <table border=1 style="border-collapse:collapse; font-size:10px"> -->
<table border=1 style="border-collapse:collapse;">
	<tr>
		<td rowspan="3">No</td>
		<td rowspan="3">Program, Kegiatan, Dan Sub Kegiatan</td>
		<td rowspan="3">Pagu</td>
		<td rowspan="3">Sumber Dana</td>
		<td colspan="3">Fisik</td>
		<td colspan="5">Keuangan</td>
	</tr>
	<tr>
		<td>Target</td>
		<td>Realisasi</td>
		<td>Deviasi</td>
		<td colspan="2">Rp</td>
		<td colspan="3">%</td>

		
	</tr>
</table>