<div class="row">
	<div class="col-md-12">
		<div id="mapid"></div>
	</div>
</div>