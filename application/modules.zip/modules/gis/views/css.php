<link rel="stylesheet" href="<?php echo base_url(); ?>assets/leaflet/leaflet.css"/>
<style>
	#mapid{
		height: 700px;
	}
</style>