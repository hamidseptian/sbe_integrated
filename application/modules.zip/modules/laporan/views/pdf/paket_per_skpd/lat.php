<style>
  .font_laporan{
    font-size:9px;
    font-family: 'arial';
  }
  table {
    
    border-collapse: collapse;
    width:100%;
}
table td, th {
    border: 0.01em solid ;
    padding:3px;
}

  .header{
    font-weight:bold;
    text-align : center;
  }


  .logo{
   float:left;
   width : 60px;
  }
  .skpd{
   float:right;
   
  }
  .clearfix{
   clear:both;
   
  }
  .kop{
   text-align:center;
   font-family: 'arial';
  }
  .penutup{
    font-size:6px;
  }
  .copyright{
    font-size:7px;
    float:left;
  }
  .page{
    float:right;
    font-size:7px;
  }
  .pemprov_sumbar{
    font-size:20px;
  }
  .garis_kop1{
    margin-top:5px;
    border-width: 1.6px;
      border-style: solid;
  }
  .garis_kop2{
    margin-top:1px;
    border-width: 1px;
      border-style: solid;
  }
  .judul_laporan{
    margin-top:15px;
    text-align : center;
    font-family: 'arial';
    font-size:10px;
  }
  .nama_kegiatan{
    white-space:pre;
    left: 30px;
  }
</style>

<head>
  <title><?php echo $title ?></title>
</head>


<body>

<table class="font_laporan border">
  <thead class="header">
    <tr>
      <th rowspan="2" width="20px">No</th>
      <th colspan="3">Data ABPD</th>
      <th colspan="5">Data Paket Pekerjaan</th>
      <th rowspan="2">Nilai Fisik Sub Kegiatan</th>
    </tr>
    <tr>
    <th>Program</th>
    <th>Kegiatan</th>
    <th>Sub Kegiatan</th>
    <th>Paket Pekerjaan</th>
    <th > Pagu</th>
    <th > Jenis Paket</th>
    <th > Metode</th> 
    <th >Nilai Paket <br> Pekerjaan</th>
   
  </tr>



 </thead>

 <tbody>
   <tr>
     <td rowspan="6">No </td>
     <td rowspan="6">Program 1 </td>
     <td rowspan="3">Kegiatan 1 </td>
     <td rowspan="2">Sub Kegiatan  1 </td>
    
   </tr>
   <tr>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
   </tr>
   <tr>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
   </tr>
   <tr>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
   </tr>
   <tr>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
   </tr>
   <tr>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
   </tr>
   <tr>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
    <td>sds</td>
   </tr>
   
 </tbody>
</table>


</body>