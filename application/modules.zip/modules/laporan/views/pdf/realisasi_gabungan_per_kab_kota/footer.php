
<div class="copyright" style="float:right" >Powered By IT - Biro Administrasi Pembangunan Tahun 2021 <br>
Penarikan Tanggal <?php echo $tanggal_penarikan ?></div>
<span class="page" style="text-align:right" >Page {PAGENO}/{nbpg}</span>
<div class="clearfix"></div>
