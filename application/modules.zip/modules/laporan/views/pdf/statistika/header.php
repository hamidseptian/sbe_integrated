


<div class="logo">
  <!-- <img src="<?php //echo base_url() ?>assets/sbe/image/logo.png" > -->
</div>
<div class="skpd">
  <center>
    <div class="kop">
      <div class="pemprov_sumbar"><b><?php echo $identitas['identitas'] ?></b></div>
      <div class="nama_instansi"><b>Statistika Data APBD</b></div>
      <div class="tahun"><b><?php echo $nama_tahap ?> Tahun <?php echo $tahun ?></b></div>


     
    </div>
  </center> 
  </div>
  <div class="clearfix"></div>

<div class="garis_kop1"></div>
<div class="garis_kop2"></div>
