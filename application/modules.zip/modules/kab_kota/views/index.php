

<div class="mb-3 card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table id="table-kab-kota" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th style="text-align: center;" width="1%">No</th>
                                <th style="text-align: center;">Logo</th>
                                <th style="text-align: center;">Kab / Kota</th>
                                <th style="text-align: center;">Wilayah</th>
                                <th style="text-align: center;">Tahun Anggaran</th>
                                <th style="text-align: center;">Tahapan APBD</th>
                                <th style="text-align: center;">Replikasi</th>
                                <th style="text-align: center;">Link Replikasi</th>
                                <th style="text-align: center;">Integrasi Replikasi</th>
                                <th style="text-align: center;">Sumberdata Sumbar SIAP</th>
                                <th style="text-align: center;"  width="10%">Action</th>
                            </tr>
                        </thead>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>