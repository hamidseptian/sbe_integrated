<?php
/**
	* Author     : Alfikri, M.Kom
	* Created By : Alfikri, M.Kom
	* E-Mail     : alfikri.name@gmail.com
	* No HP      : 081277337405
*/
?>

<div class="mb-3 card">
    <div class="card-body">
    	<div class="row">
    		<div class="col-md-12">
                <div class="table-responsive">
    		        <table id="table-reject-fisik" class="display" style="width:100%">
    		            <thead>
    		                <tr>
    		          
    		                    <th style="text-align: center;">Kode rekening</th>
                                <th style="text-align: center;">PPTK</th>
                                <th style="text-align: center;">Sub Kegiatan</th>
    		                    <th style="text-align: center;">Nama Paket</th>
                                <th style="text-align: center;">Dokumen</th>
    		                    <th style="text-align: center;"></th>
    		                </tr>
    		            </thead>
    		        </table>
                </div>
		    </div>
	    </div>
    </div>
</div>





