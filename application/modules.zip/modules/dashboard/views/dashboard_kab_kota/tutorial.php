<div class="tabs-animation">
 
    <div class="row">
        <div class="col-lg-12 col-xl-12">
            <div class="main-card mb-3 card">
                
                    <?php echo $file ?>
                                           
            </div>
        </div>
    
    </div>
</div>





